/*
 * @Author: 一凨 
 * @Date: 2018-12-27 16:25:25 
 * @Last Modified by:   一凨 
 * @Last Modified time: 2018-12-27 16:25:25 
 */

// !!! 代码示例，并非Demo
// import 'package:flutter/material.dart';
// class MaterialApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return  MaterialApp(
//       title: 'title',
//       theme:  ThemeData(
//         primaryColor: Color(ThemeColor),
//         backgroundColor: Color(0xFFEFEFEF),
//         accentColor: Color(0xFF888888),
//         textTheme: TextTheme(
//           //设置Material的默认字体样式
//           body1: TextStyle(color: Color(0xFF888888), fontSize: 16.0),
//         ),
//         iconTheme: IconThemeData(
//           color: Color(ThemeColor),
//           size: 35.0,
//         ),
//       ),
//       home:  MyHomePage(),
//       onGenerateRoute: Application.router.generator,
//     );
//   }
// }
