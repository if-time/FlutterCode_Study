import 'package:flutter/material.dart';

class LinearProgressIndicatorDemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200.0,
      child: LinearProgressIndicator(),
    );
  }
}
