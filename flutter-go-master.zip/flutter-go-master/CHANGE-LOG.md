## 更新日志


#### 2019-2-5
  - [x] 处理因为flutter版本导致的项目运行不起来
  - [x] 更新readme, 加入开发日志, 与相关说明
  - [x] 加入 首页欢迎效果图
  - [x] refactor(整理richText的说明):
  - [x] 解决一些页面的code演示打不开的问题
  - [x] add:开发规范
  - [x] add:版本更新历史链接
  - [x] Update README.md
  - [x] add:添加版本号
  - [x] feat:添加代码开发规范
  - [x] refactor(update: version & fiexed warns):
  - [x] fix(solve conflict):
  - [x] modify:toast and andrid apk label
  - [x] Add:自动 pr 工具抓取器，抓取两周前至今的,提交数据，并去重
  - [x] fix:fluttetToast backHome
  - [x] fix:modified the style of toast && remote files
  - [x] chore(删除tools/log.json):
  - [x] 重构文件结构
  - [x] 关于手册图标更换
  - [x] 增加demo: CupertinoNavigationBar CupertinoPageRoute CupertinoPageScaffold CupertinoPicker，CupertinoPopupSurface CupertinoTimerPickerDemo


#### 2019-1-24
  - [x] 功能：更新小部件的图标
  - [x] 功能：添加CupertinoTimerPickerDemo
  - [x] 调试：消除警告
  - [x] 修复：关于手册图标更换
  - [x] 添加：文案描述
  - [x] 添加：CupertinoPicker，CupertinoPopupSurface
#### 2019-1-23
  - [x] 修复: 导航栏home返回报错
  - [x] 修复：收集错误
  - [x] 添加：CupertinoNavigationBar CupertinoPageRoute CupertinoPageScaffold
#### 2019-1-22
  - [x] 功能：在Allsimon拉请求中添加英文简介
#### 2019-1-21
  - [x] 功能：Cupertino的子项
#### 2019-1-20
  - [x] 功能：CupertinoSwitch演示
  - [x] 功能：为搜索列表加入图标
  - [x] 功能：CupertinoSliverRefreshControl演示
  - [x] 功能：CupertinoSliverNavigationBar演示
#### 2019-1-18
  - [x] 更新：SharedPreferences保存数据和android设备布局溢出
  - [x] 功能：添加CupertinoScrollbar演示
  - [x] 功能：第四页暂时用欢迎页替代。后期再开发
#### 2019-1-17
  - [x] 添加：+许可证
#### 2019-1-16
  - [x] 转换：将README翻译为En语言环境
  - [x] 功能：CupertinoScrollbar演示
#### 2019-1-14
  - [x] 添加：增加手册页面
  - [x] 功能：文字演示
  - [x] 重构：修改过的图标
  - [x] 重构：文档，文章，组件收藏，新增webView
  - [x] 重构：修改过的演示
  - [x] 重构：代码视图
  - [x] 更新：版本 和readme.md
  - [x] 修改：添加代码视图
  - [x] 功能：添加搜索历史记录板
  - [x] 修改：列出加标头错误
#### 2019-1-15
  - [x] 功能：welcomepage
#### 2019-1-13
  - [x] 添加：一些输入描述
  - [x] 功能：加入GridPaper＆SliverGrid
  - [x] 重构：修改db
  - [x] 重构：删除数据库 TabBarView
  - [x] 添加：网格视图
  - [x] 修改：checkbosListTile 错误
  - [x] 修改：自动提示文案
  - [x] 功能：增加免责声明，声明组件，自动弹出，左上角入口
  - [x] 重构：整理数据库初始逻辑，判断数据库完整性，判断是否存在已知的cat，widget，collection 三张表。
  - [x] 修复：DialogDemo，无法关闭的问题
#### 2019-1-12
  - [x] 修复：icon没有，但内容有的，组件，给补充了icon
  - [x] 修改：1.整理文件 2.修正分析
  - [x] 更新：flutter_rookie_book => flutter_go
  - [x] 更新：更新SearchInput文件名=> search_input
  - [x] 修改：文件名称的大小写规范
  - [x] 修改：修正bottomNavigationBar iconButton警告
